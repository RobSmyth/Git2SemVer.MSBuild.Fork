﻿namespace NoeticTools.TestProject2
{
    public class Class1
    {

    }
}
