﻿//using System.Text.Json.Serialization;
//using Semver;

//namespace NoeticTools.Git2SemVer.Versioning.Persistence;

//internal sealed class GeneratedVersionProperties
//{
//    [JsonRequired]
//    public Version? AssemblyVersion { get; set; }

//    public string BuildContext { get; set; } = "";

//    public string BuildNumber { get; set; } = "";

//    public SemVersion? BuildSystemVersion { get; set; }

//    public int CommitsSinceLastRelease { get; set; }

//    public string FileSchema { get; set; } = "1.0.0";

//    [JsonRequired]
//    public Version? FileVersion { get; set; }

//    [JsonRequired]
//    public SemVersion? InformationalVersion { get; set; }

//    public string LastReleaseCommitId { get; set; } = "";

//    public string LastReleaseVersion { get; set; } = "";

//    [JsonRequired]
//    public SemVersion? PackageVersion { get; set; }

//    [JsonRequired]
//    public SemVersion? Version { get; set; }

//    public bool IsInInitialDevelopment { get; set; }

//    public string Output1 { get; set; } = "";

//    public string Output2 { get; set; } = "";
//}

