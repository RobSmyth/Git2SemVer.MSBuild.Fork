﻿namespace NoeticTools.Git2SemVer.MSBuild.Versioning;

public enum VersioningModeEnum
{
    StandAloneProject,
    SolutionClientProject,
    SolutionVersioningProject
}