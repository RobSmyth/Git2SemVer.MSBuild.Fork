﻿# Git2SemVer.MSBuild

**NOTE**
> This project is currently in early development.
> Early trial and feedback would be great!

TODO

Go to [documentation](https://noetictools.github.io/Git2SemVer/) for more information.

