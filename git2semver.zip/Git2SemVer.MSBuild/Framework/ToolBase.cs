﻿#pragma warning disable CS1591 // Missing XML comment for publicly visible type or member
namespace NoeticTools.Git2SemVer.MSBuild.Framework;

public abstract class ToolBase
{
    protected const int DefaultProcessTimeLimitMilliseconds = 60000;
}