﻿using System.Xml.Linq;


namespace NoeticTools.Git2SemVer.Tool.MSBuild.Projects.Elements;

public sealed class ItemElement : KeyValuePairElement
{
    public ItemElement(XElement element)
    {
        throw new NotImplementedException();
    }
}