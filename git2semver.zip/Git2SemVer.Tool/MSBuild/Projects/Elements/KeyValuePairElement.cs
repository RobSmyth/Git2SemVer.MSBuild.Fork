﻿namespace NoeticTools.Git2SemVer.Tool.MSBuild.Projects.Elements;

public abstract class KeyValuePairElement
{
}