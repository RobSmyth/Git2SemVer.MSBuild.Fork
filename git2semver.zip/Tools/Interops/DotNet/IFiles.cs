﻿namespace NoeticTools.Common.Interops.DotNet;

public interface IFiles
{
    bool Exists(string filePath);
}