﻿---
uid: working-with-the-code
---
![](../Images/Git2SemVer_banner_840x70.png)

# Working with the code

=== TODO ===

## Branching strategy

The project uses the [GitHub Flow](https://githubflow.github.io/) branching strategy.

## Testing

=== TODO ===

Build systems

## Building

=== TODO ===
Build servers & release process.

Versioning.

## Building documentation

The documentation is build by [docfx](https://dotnet.github.io/docfx/).

Build a local preview from project's root folder with the command line:

```winbatch
docfx Documentation/docfx.json --serve
```

Preview and when ready run this command from the Documentation project folder to rebuild the website:

```winbatch
docfx Documentation/docfx.json
```

Documentation is published from the main branch by a GitHub action.


## Coding standard

=== TODO ===


## How to add a build system

=== TODO ===
